// import React, { createContext, useContext, useState, ReactNode } from "react";
// import prisma from "@/lib/prisma";
// import { getSession } from "@/lib/auth";

// interface UserDataContextProps {
//   data: Record<string, any>;
//   setData: React.Dispatch<React.SetStateAction<Record<string, any>>>;
// }

// const valueData = createContext<UserDataContextProps | undefined>(undefined);

// export const UserData = (): UserDataContextProps => {
//   const context = useContext(valueData);
//   if (!context) {
//     throw new Error("UserData must be used within a UserDataValue provider");
//   }
//   return context;
// };

// interface UserDataValueProps {
//   children: ReactNode;
// }

// export const UserDataValue: React.FC<UserDataValueProps> = ({ children }) => {
//   const session = await getSession();
//   const sites = await prisma?.site.findMany({
//     where: {
//       user: {
//         id: session.user.id as string,
//       },
//     },
//     orderBy: {
//       createdAt: "asc",
//     // },
//     // ...(limit ? { take: limit } : {}),
//   });

//   return (
//     <valueData.Provider value={{ sites }}>
//       {children}
//     </valueData.Provider>
//   );
// };
