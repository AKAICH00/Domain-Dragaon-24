import { User } from "@prisma/client";
import BlurImage from "./blur-image";

const BlogAvatar = ({ user }: { user?: User | null }) => {
  return (
    <a
      // if you are using Github OAuth, you can get rid of the Twitter option
      href={
        user?.username
          ? `https://twitter.com/${user.username}`
          : `https://github.com/${user?.gh_username}`
      }
      rel="noreferrer"
      target="_blank"
    >
      <div className="my-8 flex">
        <div className="relative h-8 w-8 overflow-visible  align-middle md:h-12 md:w-12">
          {user?.image ? (
            <BlurImage
              alt={user?.name ?? "User Avatar"}
              height={80}
              src={user.image}
              width={80}
              className="rounded-full"
            />
          ) : (
            <div className="absolute flex h-full w-full select-none items-center justify-center bg-stone-100 text-4xl text-stone-500">
              ?
            </div>
          )}
        </div>
        <div className="text-md ml-3 inline-block align-middle md:text-lg dark:text-white">
          by <span className="font-semibold">{user?.name}</span>
        </div>
      </div>
    </a>
  );
};

export default BlogAvatar;
