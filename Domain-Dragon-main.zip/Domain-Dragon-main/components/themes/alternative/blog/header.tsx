import BlogAvatar from "@/components/blog-avatar";
import BlurImage from "@/components/blur-image";
import { IPost } from "@/lib/types/post";
import { placeholderBlurhash, toDateString } from "@/lib/utils";

const DefaultHeader = ({ post }: { post: IPost }) => {
  return (
    <>
      <div className="relative m-auto mb-10 h-80 w-full max-w-screen-lg overflow-hidden md:mb-20 md:h-150 md:w-5/6 md:rounded-2xl lg:w-2/3">
        <BlurImage
          alt={post.title ?? "Post image"}
          width={1200}
          height={630}
          className="h-full w-full object-cover"
          placeholder="blur"
          blurDataURL={post.imageBlurhash ?? placeholderBlurhash}
          src={post.image ?? "/placeholder.png"}
        />
      </div>
      <div className="flex flex-col items-start justify-center">
        <div className="m-auto w-full  md:w-7/12">
          <div className="flex">
            <BlogAvatar user={post?.site?.user} />
            <div className="flex w-full items-center justify-center">
              <div className="h-6 border-l border-stone-600 dark:border-stone-400" />
              <p className="my-5 w-10/12 pl-4 text-sm font-light text-stone-500 md:text-base dark:text-stone-400">
                {toDateString(post.createdAt)}
              </p>
            </div>
          </div>
          <h1 className="mb-10 font-title text-3xl font-bold text-stone-800 md:text-6xl dark:text-white">
            {post.title}
          </h1>
          <p className="text-md  w-10/12 text-stone-600 md:text-lg dark:text-stone-400">
            {post.description}
          </p>
        </div>
      </div>
    </>
  );
};

export default DefaultHeader;
