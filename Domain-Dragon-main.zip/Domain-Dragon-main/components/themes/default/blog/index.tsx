import MDX from "@/components/mdx";
import { IPost } from "@/lib/types/post";
import DefaultHeader from "./header";
import DefaultReadMore from "./read-more";

const DefaultBlog = ({ post }: { post: IPost }) => {
  return (
    <>
      <DefaultHeader post={post} />

      <MDX source={post.mdxSource} />

      <DefaultReadMore adjacentPosts={post.adjacentPosts} />
    </>
  );
};

export default DefaultBlog;
