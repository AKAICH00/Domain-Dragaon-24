import React from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSpinner } from "@fortawesome/free-solid-svg-icons";

const loadingSpinnerStyle: React.CSSProperties = {
  margin: "auto",
  width: "50%",
  maxWidth: 40,
  minWidth: 40,
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(110px, -50%)",
  fontSize: 20,
  zIndex: 10000
};

const Spinner=()=>{
  return (
    <div style={loadingSpinnerStyle}>
      <div style={{ alignContent: "center" }} className="text-gray-800">
        <FontAwesomeIcon icon={faSpinner} className="fa-spin fa-pulse fa-2xl" />
      </div>
    </div>
  );
}

export default Spinner;
