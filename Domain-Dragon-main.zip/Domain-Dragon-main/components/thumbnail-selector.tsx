"use client"

import { Card, CardContent } from "@/components/ui/card"
import {
    Carousel,
    CarouselApi,
    CarouselContent,
    CarouselItem
} from "@/components/ui/carousel"
import { getBlurDataURL } from "@/lib/utils"
import Image from "next/image"
import { useParams, useRouter } from "next/navigation";
import { toast } from "sonner";
import va from "@vercel/analytics";

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"

export function ThumbnailSelector({ selectedImage, images, handleClick }: { selectedImage: string, images: string[], handleClick: any }) {
    const { update } = useSession();

    const { id } = useParams() as { id?: string };
    const [api, setApi] = useState<CarouselApi>()
    const [current, setCurrent] = useState(0)
    const [count, setCount] = useState(0)
    const router = useRouter();

    const onClickHandler = async (image: string) => {

        const formData = new FormData()
        formData.set("image", image)
        handleClick(formData, id, "image").then(async (res: any) => {
            if (res.error) {
                toast.error(res.error);
            } else {
                va.track(`Updated image`, id ? { id } : {});
                if (id) {
                    router.refresh();
                } else {
                    await update();
                    router.refresh();
                }
                toast.success(`Successfully updated image!`);
            }
        });
    }

    useEffect(() => {
        if (!api) {
            return
        }

        setCount(api.scrollSnapList().length)
        setCurrent(api.selectedScrollSnap() + 1)

        api.on("select", () => {
            console.log("current")
            setCurrent(api.selectedScrollSnap() + 1)
        })
    }, [api])
    console.log("current", current, count, typeof current, typeof count, current === count)

    return (
        <div>
            <Carousel setApi={setApi} className="w-full max-w-xs">
                <CarouselContent>
                    {images.map((image, index) => (
                        <CarouselItem className={`"  basis-1/3 hover:cursor-pointer "`} onClick={() => {
                            onClickHandler(image)
                        }} key={index}>
                            <Card className={`" ${selectedImage === image ? "border-2 border-sky-500" : ""} "`}>
                                <CardContent className={`" flex aspect-square items-center justify-center p-6"`}>
                                    {/* <span className="text-4xl font-semibold">{index + 1}</span> */}
                                    <Image src={image} width={300} height={300} alt="image" />
                                </CardContent>
                            </Card>
                        </CarouselItem>
                    ))}
                </CarouselContent>
                {/* <CarouselPrevious /> */}
                {/* <CarouselNext /> */}

            </Carousel>
            <div className="py-2 text-center text-sm text-muted-foreground flex  items-center justify-center">
                {/* Slide {current} of {count} */}
                {Array.from({ length: count }).map((_, index) => (
                    <p key={index} className={`${current - 1 == index ? "text-lg" : "text-sm"}`}>⚬</p>
                ))}

            </div>
        </div >
    )
}
