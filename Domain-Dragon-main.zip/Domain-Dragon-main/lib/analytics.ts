import { Site } from "@prisma/client";
import { getSession, withSiteAuth } from "./auth";
import {
  getKpiTotals,
  getKpis,
  getTopBrowsers,
  getTopDevices,
  getTopLocations,
  getTopPages,
  getTopSitesGrowth,
  getTopSources,
  getTrend,
} from "./tinybird";
import { TopLocationsSorting } from "./types/top-locations";
import { TopPagesSorting } from "./types/top-pages";

export const getTopSitesGrowthApi = async () => {
  const session = await getSession();
  if (!session) {
    return {
      error: "Not authenticated",
    };
  }
  const { data } = await getTopSitesGrowth(session.user.id ?? "");
  return { data };
};

export const getTenantKpiApi = async () => {
  const session = await getSession();
  if (!session) {
    return {
      error: "Not authenticated",
    };
  }
  const { data, dates } = await getKpis("visits", session.user.id ?? "");
  return { data, dates };
};

export const getTenantKpiTotalApi = async () => {
  const session = await getSession();
  if (!session) {
    return {
      error: "Not authenticated",
    };
  }
  const { avg_session_sec, pageviews, visits, bounce_rate } =
    await getKpiTotals(session.user.id ?? "");

  return { avg_session_sec, pageviews, visits, bounce_rate };
};

export const getSiteKpiApi = withSiteAuth(async (_: FormData, site: Site) => {
  const { data, dates } = await getKpis("visits", site?.userId ?? "", site?.id);
  return { data, dates };
});

export const getSiteKpiTotalApi = withSiteAuth(
  async (_: FormData, site: Site) => {
    const { avg_session_sec, pageviews, visits, bounce_rate } =
      await getKpiTotals(site?.userId ?? "", site?.id);

    return { avg_session_sec, pageviews, visits, bounce_rate };
  },
);

export const getTopBrowserApi = withSiteAuth(
  async (_: FormData, site: Site) => {
    const { data } = await getTopBrowsers(site?.userId ?? "", site?.id);

    return { data };
  },
);

export const getTrendApi = withSiteAuth(async (_: FormData, site: Site) => {
  const { visits, dates, totalVisits, data } = await getTrend(
    site?.userId ?? "",
    site?.id,
  );

  return { visits, dates, totalVisits, data };
});

export const getTopSourcesApi = withSiteAuth(
  async (_: FormData, site: Site) => {
    const { data, refs, visits } = await getTopSources(
      site?.userId ?? "",
      site?.id,
    );

    return { data, refs, visits };
  },
);

export const getTopPagesApi = withSiteAuth(async (_: FormData, site: Site) => {
  const { data, columns, pages, labels } = await getTopPages(
    TopPagesSorting.Pageviews,
    site?.userId ?? "",
    site?.id,
  );

  return { data, columns, pages, labels };
});

export const getTopLocationsApi = withSiteAuth(
  async (_: FormData, site: Site) => {
    const { data, locations, labels } = await getTopLocations(
      TopLocationsSorting.Pageviews,
      site?.userId ?? "",
      site?.id,
    );

    return { data, locations, labels };
  },
);

export const getTopDevicesApi = withSiteAuth(
  async (_: FormData, site: Site) => {
    const { data } = await getTopDevices(site?.userId ?? "", site?.id);

    return { data };
  },
);
