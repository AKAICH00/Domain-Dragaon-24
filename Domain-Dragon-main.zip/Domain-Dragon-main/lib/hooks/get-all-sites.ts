import { useEffect, useState } from "react";
interface Site {
  id: string | null;
  name: string | null;
  description: string | null;
  logo: string | null;
  font: string | null;
  image: string | null;
  imageBlurhash: string | null;
  subdomain: string | null;
  customDomain: string | null;
  keywords: string | null;
  message404: string | null;
  longDescription: string | null;
  prompt: string | null;
  createdAt: Date | null;
  updatedAt: Date | null;
  userId: string | null;
}

export const useCurrentUser = () => {
  const [value, setValue] = useState<Site[]>([]);
  const [status, setStatus] = useState<"idle" | "loading" | "error">("idle");

  useEffect(() => {
    const fetchData = async () => {
      setStatus("loading");

      const response = await fetch("/api/sites");

      if (!response.ok) {
        console.error("Failed to fetch data");
        setStatus("error");
        return;
      }

      const data = await response.json();
      setStatus("idle");
      console.log(data, "datadatadata");
      setValue(data.response);
    };

    fetchData();
  }, []);

  return { value, status };
};
