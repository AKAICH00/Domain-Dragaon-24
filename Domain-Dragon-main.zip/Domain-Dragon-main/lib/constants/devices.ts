const devices = {
  desktop: 'Desktop',
  'mobile-android': 'Android',
  'mobile-ios': 'iOS',
  bot: 'Bots',
}

export default devices
