const browsers = {
  chrome: 'Chrome',
  safari: 'Safari',
  opera: 'Opera',
  firefox: 'Firefox',
  ie: 'IE',
}

export default browsers
