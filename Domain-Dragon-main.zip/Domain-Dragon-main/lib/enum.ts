export enum Theme {
  default = "theme-default",
  alternative = "theme-alternative",
}
