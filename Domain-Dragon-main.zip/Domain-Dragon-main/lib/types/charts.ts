export type ChartValue = number | string
