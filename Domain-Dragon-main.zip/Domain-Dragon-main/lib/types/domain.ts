export type DomainQueryData = { domain: string }

export type DomainData = {
  domain: string | null
  logo: string
}
