export enum HostType {
  Eu = 'https://ui.tinybird.co',
  Us = 'https://ui.us-east.tinybird.co',
  Other = 'other',
}
