export interface OptionType<T> {
  text: string
  value: T
}
