import { Post, User } from "@prisma/client";
import { Site } from "../types";
import { MDXRemoteSerializeResult } from "next-mdx-remote";

export interface ISiteWithUser extends Site {
  user: User | null;
}

export interface IAdjacentPost {
  title: string | null;
  description: string | null;
  slug: string;
  image: string | null;
  imageBlurhash: string | null;
  createdAt: Date;
}

export interface IPost extends Post {
  site: ISiteWithUser | null;
  mdxSource: MDXRemoteSerializeResult<
    Record<string, unknown>,
    Record<string, unknown>
  >;
  adjacentPosts: IAdjacentPost[];
}

export interface IPostInfo {
  slug: string;
  image: string | null;
  imageBlurhash: string | null;
  title: string | null;
  description: string | null;
  createdAt: Date;
}
