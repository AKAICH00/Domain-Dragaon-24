import { getSession } from "@/lib/auth";
import prisma from "@/lib/prisma";
import { notFound, redirect } from "next/navigation";
import Editor from "@/components/editor";
import { updatePostMetadata } from "@/lib/actions";
import Form from "@/components/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PostSettings from "./settings/page";
import DeletePostForm from "@/components/form/delete-post-form";
import { ThumbnailSelector } from "@/components/thumbnail-selector";
import { extractImagesFromMarkdown } from "@/lib/utils";

export default async function PostPage({ params }: { params: { id: string } }) {
  const session = await getSession();
  if (!session) {
    redirect("/login");
  }
  const data = await prisma.post.findUnique({
    where: {
      id: decodeURIComponent(params.id),
    },
    include: {
      site: {
        select: {
          subdomain: true,
        },
      },
    },
  });
  if (!data || data.userId !== session.user.id) {
    notFound();
  }
  const images = extractImagesFromMarkdown(data?.content ?? "");

  return (
    <>

      <Tabs defaultValue="editor" className="">
        <TabsList className="mb-4">
          <TabsTrigger value="editor">Editor</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>
        <TabsContent value="editor">
          <Editor post={data} />
        </TabsContent>
        <TabsContent value="settings">
          <div className="flex flex-col space-y-6">
            <h1 className="font-cal text-3xl font-bold dark:text-white">
              Post Settings
            </h1>
            <Form
              title="Post Slug"
              description="The slug is the URL-friendly version of the name. It is usually all lowercase and contains only letters, numbers, and hyphens."
              helpText="Please use a slug that is unique to this post."
              inputAttrs={{
                name: "slug",
                type: "text",
                defaultValue: data?.slug!,
                placeholder: "slug",
              }}
              handleSubmit={updatePostMetadata}
            />
            <Form
              title="Thumbnail image"
              description="The thumbnail image for your post. Accepted formats: .png, .jpg, .jpeg"
              helpText="Max file size 50MB. Recommended size 1200x630."
              inputAttrs={{
                name: "image",
                type: "file",
                defaultValue: data?.image!,
              }}
              handleSubmit={updatePostMetadata}
            >
              {
                images ?
                  <ThumbnailSelector
                    selectedImage={data?.image!}
                    images={images}
                    handleClick={updatePostMetadata}

                  /> : null
              }
            </Form>

            <DeletePostForm postName={data?.title!} />
          </div>
        </TabsContent>
      </Tabs>

    </>
  );
}
export const dynamic = "force-dynamic";
