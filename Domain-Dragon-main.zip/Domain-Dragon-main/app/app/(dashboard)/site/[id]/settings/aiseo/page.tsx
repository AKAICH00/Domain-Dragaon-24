import React from "react";
import prisma from "@/lib/prisma";
import Form from "@/components/form";
import { updateSite } from "@/lib/actions";
import KeywordForm from "@/components/form/keywords-form";

export default async function SiteSettingsAISEO({
  params,
}: {
  params: { id: string };
}) {
  const data = await prisma.site.findUnique({
    where: {
      id: decodeURIComponent(params.id),
    },
  });
  const allKeywords = data?.keywords?.split(",");

  return (
    <div>
      <div className="flex gap-4">
        {allKeywords?.map((item: string, index: number) => (
          <KeywordForm
            key={index}
            title={`Keyword ${index + 1}`}
            inputAttrs={{
              name: `keyword${index}`,
              type: "text",
              defaultValue: item,
              placeholder: `Enter Keyword ${index + 1}`,
              maxLength: 32,
            }}
            handleSubmit={updateSite}
          />
        ))}
      </div>
      <div className="flex flex-col space-y-6">
        <Form
          title="Long Description"
          description="The long description of your site. This will be used as the meta title on Google as well."
          helpText="Please use 32 characters maximum."
          inputAttrs={{
            name: "longDescription",
            type: "text",
            defaultValue: data?.longDescription!,
            placeholder: "My Awesome Site",
            maxLength: 32,
          }}
          handleSubmit={updateSite}
        />
        <Form
          title="GPT PROMPT"
          description="The gpt prompt of your site. This will be used as the meta title on Google as well."
          helpText="Please use 32 characters maximum."
          inputAttrs={{
            name: "prompt",
            type: "text",
            defaultValue: data?.prompt!,
            placeholder: "My Awesome Site",
            maxLength: 32,
          }}
          handleSubmit={updateSite}
        />
      </div>
    </div>
  );
}
