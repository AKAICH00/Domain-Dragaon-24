"use client";

import React, { useState, ChangeEvent, FormEvent, useEffect } from "react";
import { parse } from "csv-parse";
import { createSitesFromCSV } from "@/lib/actions";
import { toast } from "sonner";
import CreateSiteButton from "@/components/create-site-button";
import CreateSiteModal from "@/components/modal/create-site";
import Papa from "papaparse";
import { data } from "@/lib/utils";
import prisma from "@/lib/prisma";
import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import Spinner from "@/components/spinner";
import { useSession } from "next-auth/react";
import { PrismaClient } from "@prisma/client";
import { useCurrentUser } from "@/lib/hooks/get-all-sites";
import Link from "next/link";

interface SiteData {
  domainName: string;
  keywords: string[];
  shortDescription: string;
  longDescription: string;
  prompt: string;
}

const statuses: Record<string, string> = {
  Completed: "text-green-400 bg-green-400/10",
  Error: "text-rose-400 bg-rose-400/10",
};
function classNames(...classes: any) {
  return classes.filter(Boolean).join(" ");
}
const Page = () => {
  const [open, setOpen] = useState<Boolean>();
  const { value, status } = useCurrentUser();
  const userName = useSession();
  const generateCSV = () => {
    const csv = Papa.unparse(data);
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "data.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleFileChange = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    setOpen(true);
    if (!file) {
      console.error("No CSV file selected");
      return;
    }

    const reader = new FileReader();

    reader.onload = (e) => {
      const content = e.target?.result as string;
      if (!content) {
        console.error("No CSV data available");
        return;
      }

      parse(content, { columns: true }, async (err, records) => {
        if (err) {
          console.error("Error parsing CSV:", err);
          return;
        }

        const parsedSites: SiteData[] = records.map((record: any) => ({
          domainName: record["Domain Name"],
          shortDescription: record["Short Description"],
          longDescription: record["Long Description"],
          keywords: [
            record["Keyword 1"],
            record["Keyword 2"],
            record["Keyword 3"],
            record["Keyword 4"],
          ],
          prompt: record["GPT Prompt for content generation"],
        }));
        try {
          const createdSites = await createSitesFromCSV(parsedSites);
          console.log("first", createdSites);
          if (createdSites) {
            // toast.success("Multiple Domain Created Successfully");
            setOpen(false);
            window.location.reload();
            toast.success("Multiple Domain Created Successfully");
          } else {
            toast.error("Error creating site");
          }
        } catch (error) {
          console.error("Error creating sites:", error);
        }
      });
    };

    reader.readAsText(file);
  };

  return (
    <>
      <div>
        <div className="flex items-center justify-between p-8">
          <h1 className="font-cal text-3xl font-bold dark:text-white">
            Domain Management
          </h1>
          <div className="flex items-center justify-between gap-5">
            <CreateSiteButton>
              <CreateSiteModal />
            </CreateSiteButton>
            <button
              className="cursor-pointer rounded-lg border border-black bg-black px-4 py-1.5 text-sm font-medium text-white transition-all hover:bg-white hover:text-black active:bg-stone-100 dark:border-stone-700 dark:hover:border-stone-200 dark:hover:bg-black dark:hover:text-white dark:active:bg-stone-800"
              onClick={generateCSV}
            >
              Download CSV
            </button>
            <form>
              <input
                type="file"
                id="csvFile"
                onChange={handleFileChange}
                accept=".csv"
                className="hidden"
              />
              <label
                htmlFor="csvFile"
                className="cursor-pointer rounded-lg border border-black bg-black px-4 py-1.5 text-sm font-medium text-white transition-all hover:bg-white hover:text-black active:bg-stone-100 dark:border-stone-700 dark:hover:border-stone-200 dark:hover:bg-black dark:hover:text-white dark:active:bg-stone-800"
              >
                Upload Bulk CSV
              </label>
            </form>
          </div>
        </div>
        {open ? (
          <Spinner />
        ) : (
          <div className="container">
            {status === "loading" ? (
              <Spinner />
            ) : value.length > 0 ? (
              <div className="bg-gray-900 ">
                <table className=" w-full whitespace-nowrap text-left">
                  <thead className="border-b border-white/10 text-sm leading-6 text-white">
                    <tr className="">
                      <th className="py-4 pl-4 pr-8 font-semibold  sm:pl-6 lg:pl-8"></th>
                      <th className="py-4 pl-4 pr-8 text-[18px] font-semibold  sm:pl-6 lg:pl-8">
                        Domain Name
                      </th>
                      <th className="hidden px-4 py-4 pl-6 text-left text-[18px] font-semibold  sm:table-cell ">
                        Status
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {value.map((item) => (
                      <tr key={item.id} className=" font-[300] text-black ">
                        <td className="py-4 pl-4 pr-8 sm:pl-6 lg:pl-8"></td>
                        <td className="py-4 pl-4 pr-8 sm:pl-6 lg:pl-8">
                          <div className="truncate  text-sm font-medium leading-6 text-white">
                            <Link
                              href={`/site/${item.id}`}
                              className="flex flex-col overflow-hidden rounded-lg"
                            >
                              {item.name}
                            </Link>
                          </div>
                        </td>
                        <td className="px-4  py-4 text-sm leading-6 ">
                          <div className="flex items-center justify-end gap-x-2 sm:justify-start">
                            <div
                              className={classNames(
                                statuses[item.name ? "Completed" : "Error"],
                                "flex-none rounded-full p-1",
                              )}
                            >
                              <div className="h-1.5 w-1.5 rounded-full bg-current" />
                            </div>
                            <div className="hidden text-white sm:block">
                              {item.name ? "Active" : ""}
                            </div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="min-h-[calc(100vh_-_200px)] flex items-center justify-center">
                {userName?.data?.user?.name
                  ?
                  <div className="max-w-[500px] w-full text-[16px] p-5 bg-white rounded-lg shadow-lg border border-gray-400 ">
                    <p>
                      {userName?.data?.user?.name}, welcome to your domain management portal. To get started add a single domain or download a CSV file template to upload multiple domains.
                    </p>
                    <p className="mt-3 block">


                      Be sure to include four main keywords, a short description of what your site is about, and a prompt for domain dragon ai to start crafting your content.
                    </p>
                  </div>
                  :


                  null}
              </div>
            )}
          </div>
        )}
      </div>
    </>
  );
};

export default Page;
