import { InlineSnippet } from "@/components/form/domain-configuration";
import Image from "next/image";

export default function HomePage() {
  return (
    <div className="flex h-screen flex-col items-center justify-center space-y-10 bg-black">
      <Image
        width={512}
        height={512}
        src="/logo.png"
        alt="Platforms on Vercel"
        className="w-48"
      />
      <h1 className="text-4xl text-white">
        Domain Dragon Bringing the power of AI to top domainers worldwide.
      </h1>
      <p className="cursor-pointer rounded-lg bg-blue-900 px-4 py-2 text-blue-100">
        Apply for early access
      </p>
    </div>
  );
}
