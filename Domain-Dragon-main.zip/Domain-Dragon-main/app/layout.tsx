import { cn } from "@/lib/utils";
import { cal, inter } from "@/styles/fonts";
import "@/styles/globals.css";
import { Analytics } from "@vercel/analytics/react";
import { Metadata } from "next";
import { Providers } from "./providers";
// import { UserDataValue } from "@/context/data";

const title =
  "Domain Dragon - Bringing the power of AI to top domainers worldwide.";
const description =
  "Domain Dragon Bringing the power of AI to top domainers worldwide.";
const image = "/logo.png";

export const metadata: Metadata = {
  title,
  description,
  openGraph: {
    title,
    description,
    images: [image],
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={cn(cal.variable, inter.variable, "dark")}>
        <Providers>
          {/* <UserDataValue> */}
          {children}
          {/* </UserDataValue> */}
          <Analytics />
        </Providers>
      </body>
    </html>
  );
}
