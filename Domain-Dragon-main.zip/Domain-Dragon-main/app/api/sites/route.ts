/* 
    This was the migration script we used to migrate from
    our old database to the new Vercel Postgres database.
    It's not needed anymore, but I'm keeping it here for
    posterity.
*/
import prisma from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import {  redirect } from "next/navigation";

import { NextResponse } from "next/server";

export async function GET() {
  const session = await getSession();
  if (!session) {
    redirect("/login");
  }
  const sites = await prisma?.site.findMany({
    where: {
      user: {
        id: session.user.id as string,
      },
    },
  });
  return NextResponse.json({ response: sites });
}
