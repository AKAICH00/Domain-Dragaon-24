import DefaultBlog from "@/components/themes/default/blog";
import AlternativeSite from "@/components/themes/default/site";
import DefaultSite from "@/components/themes/default/site";
import { Theme } from "@/lib/enum";
import { getPostsForSite, getSiteData } from "@/lib/fetchers";
import prisma from "@/lib/prisma";
import { notFound } from "next/navigation";

export async function generateStaticParams() {
  const allSites = await prisma?.site.findMany({
    select: {
      subdomain: true,
      customDomain: true,
    },
    // feel free to remove this filter if you want to generate paths for all sites
    where: {
      subdomain: "demo",
    },
  });

  const allPaths = allSites
    .flatMap(({ subdomain, customDomain }) => [
      subdomain && {
        domain: `${subdomain}.${process.env.NEXT_PUBLIC_ROOT_DOMAIN}`,
      },
      customDomain && {
        domain: customDomain,
      },
    ])
    .filter(Boolean);

  return allPaths;
}

export default async function SiteHomePage({
  params,
}: {
  params: { domain: string };
}) {
  const domain = decodeURIComponent(params.domain);
  const [data, posts] = await Promise.all([
    getSiteData(domain),
    getPostsForSite(domain),
  ]);

  if (!data) {
    notFound();
  }

  return (
    <>
      {data?.theme === Theme.default && (
        <DefaultSite site={data} posts={posts} />
      )}
      {data?.theme === Theme.alternative && (
        <AlternativeSite site={data} posts={posts} />
      )}
    </>
  );
}
